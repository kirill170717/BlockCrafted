﻿using UnityEngine;

namespace ChunkScripts
{
    public static class ChunkExtensions
    {
        public static Vector2Int GetChunkContainingBlock(Vector3Int blockWorldPosition)
        {
            var x = (float)blockWorldPosition.x / Consts.Chunk.CHUNK_WIDTH;
            var y = (float)blockWorldPosition.z / Consts.Chunk.CHUNK_WIDTH;
            var chunkPosition = Vector2Int.FloorToInt(new Vector2(x, y));
            return chunkPosition;
        }
    }
}