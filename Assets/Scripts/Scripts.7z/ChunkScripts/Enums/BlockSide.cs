﻿namespace ChunkScripts.Enums
{
    public enum BlockSide : byte
    {
        None,
        Up,
        Down,
        Left,
        Right,
        Front,
        Back
    }
}