﻿namespace ChunkScripts.Enums
{
    public enum BlockType
    {
        Air,
        Grass,
        Dirt,
        Gravel,
        Stone,
        Bedrock,
    }
}