﻿using System.Collections.Generic;
using ChunkScripts;
using ChunkScripts.Enums;
using UnityEngine;

namespace MeshScripts
{
    public static class MeshBuilder
    {
        public static GeneratedMeshData GeneratedMesh(ChunkData chunkData)
        {
            var vertices = new List<GeneratedMeshVertex>();
            var maxY = 0;

            for (int y = 0; y < Consts.Chunk.CHUNK_HEIGHT; y++)
            {
                for (int x = 0; x < Consts.Chunk.CHUNK_WIDTH; x++)
                {
                    for (int z = 0; z < Consts.Chunk.CHUNK_WIDTH; z++)
                    {
                        var isGenerated = GenerateBlock(new Vector3Int(x, y, z), vertices, chunkData);

                        if (isGenerated && maxY < y) maxY = y;
                    }
                }
            }

            var boundsSize = new Vector3(Consts.Chunk.CHUNK_WIDTH, maxY, Consts.Chunk.CHUNK_WIDTH) * Consts.Chunk.BLOCK_SCALE;
            var mesh = new GeneratedMeshData
            {
                Vertices = vertices.ToArray(),
                Bounds = new Bounds(boundsSize / 2, boundsSize),
                ChunkData = chunkData
            };
            return mesh;
        }

        private static bool GenerateBlock(Vector3Int position, List<GeneratedMeshVertex> vertices, ChunkData chunkData)
        {
            var blockType = GetBlockAtPosition(position, chunkData);

            if (blockType == BlockType.Air) return false;

            var parameters = new SideParameters
            {
                BlockType = blockType,
                BlockSide = BlockSide.None,
                BlockPosition = position,
                Vertices = vertices,
            };

            parameters.BlockSide = BlockSide.Up;
            GenerateSide(parameters, chunkData);
            
            parameters.BlockSide = BlockSide.Down;
            GenerateSide(parameters, chunkData);
            
            parameters.BlockSide = BlockSide.Left;
            GenerateSide(parameters, chunkData);

            parameters.BlockSide = BlockSide.Right;
            GenerateSide(parameters, chunkData);

            parameters.BlockSide = BlockSide.Front;
            GenerateSide(parameters, chunkData);

            parameters.BlockSide = BlockSide.Back;
            GenerateSide(parameters, chunkData);
            
            return true;
        }

        private static void GenerateSide(SideParameters parameters, ChunkData chunkData)
        {
            var direction = GetDirection(parameters.BlockSide);
            var blockTypeAtPosition = GetBlockAtPosition(parameters.BlockPosition + direction, chunkData);
            var isBlock = blockTypeAtPosition != BlockType.Air;
            var isBottomOfWorld = parameters.BlockSide == BlockSide.Down && parameters.BlockPosition.y == 0;

            if (isBlock || isBottomOfWorld) return;

            GenerateSideVertices(parameters);
        }

        private static Vector3Int GetDirection(BlockSide side)
        {
            return side switch
            {
                BlockSide.Left => Vector3Int.left,
                BlockSide.Right => Vector3Int.right,
                BlockSide.Front => Vector3Int.forward,
                BlockSide.Back => Vector3Int.back,
                BlockSide.Up => Vector3Int.up,
                BlockSide.Down => Vector3Int.down,
                _ => Vector3Int.zero
            };
        }

        private static void GenerateSideVertices(SideParameters parameters)
        {
            var vertex = new GeneratedMeshVertex
            {
                NormalX = sbyte.MaxValue,
                NormalY = 0,
                NormalZ = 0,
                NormalW = 1
            };
            GetUVs(parameters.BlockType, parameters.BlockSide, out vertex.UVx, out vertex.UVy);

            switch (parameters.BlockSide)
            {
                case BlockSide.Left:
                    vertex.Position = (new Vector3(0, 0, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(0, 0, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(0, 1, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(0, 1, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    break;
                case BlockSide.Right:
                    vertex.Position = (new Vector3(1, 0, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 1, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 0, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 1, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    break;
                case BlockSide.Front:
                    vertex.Position = (new Vector3(0, 0, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 0, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(0, 1, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 1, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    break;
                case BlockSide.Back:
                    vertex.Position = (new Vector3(0, 0, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(0, 1, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 0, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 1, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    break;
                case BlockSide.Up:
                    vertex.Position = (new Vector3(0, 1, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(0, 1, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 1, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 1, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    break;
                case BlockSide.Down:
                    vertex.Position = (new Vector3(0, 0, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 0, 0) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(0, 0, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    vertex.Position = (new Vector3(1, 0, 1) + parameters.BlockPosition) * Consts.Chunk.BLOCK_SCALE;
                    parameters.Vertices.Add(vertex);
                    break;
            }
        }

        private static void GetUVs(BlockType blockType, BlockSide blockSide, out ushort x, out ushort y)
        {
            x = 0;
            y = 0;

            switch (blockType)
            {
                case BlockType.Grass:
                    switch (blockSide)
                    {
                        case BlockSide.Up:
                            x = 0 * 256;
                            y = 240 * 256;
                            break;
                        case BlockSide.Down:
                            x = 32 * 256;
                            y = 240 * 256;
                            break;
                        case BlockSide.Left:
                        case BlockSide.Right:
                        case BlockSide.Front:
                        case BlockSide.Back:
                            x = 48 * 256;
                            y = 240 * 256;
                            break;
                    }

                    break;
                case BlockType.Dirt:
                    x = 32 * 256;
                    y = 240 * 256;
                    break;
                case BlockType.Gravel:
                    x = 48 * 256;
                    y = 224 * 256;
                    break;
                case BlockType.Stone:
                    x = 16 * 256;
                    y = 240 * 256;
                    break;
                case BlockType.Bedrock:
                    x = 16 * 256;
                    y = 224 * 256;
                    break;
                default:
                    x = 160 * 256;
                    y = 224 * 256;
                    break;
            }
        }

        private static BlockType GetBlockAtPosition(Vector3Int blockPosition, ChunkData chunkData)
        {
            int index;

            if (blockPosition.x >= 0 && blockPosition.x < Consts.Chunk.CHUNK_WIDTH && blockPosition.y >= 0 &&
                blockPosition.y < Consts.Chunk.CHUNK_HEIGHT && blockPosition.z >= 0 &&
                blockPosition.z < Consts.Chunk.CHUNK_WIDTH)
            {
                index = blockPosition.x + blockPosition.y * Consts.Chunk.CHUNK_WIDTH_SQ +
                        blockPosition.z * Consts.Chunk.CHUNK_WIDTH;
                return chunkData.Blocks[index];
            }

            if (blockPosition.y < 0 || blockPosition.y >= Consts.Chunk.CHUNK_HEIGHT) return BlockType.Air;

            if (blockPosition.x < 0)
            {
                if (chunkData.LeftChunk == null) return BlockType.Air;

                blockPosition.x += Consts.Chunk.CHUNK_WIDTH;
                index = blockPosition.x + blockPosition.y * Consts.Chunk.CHUNK_WIDTH_SQ +
                        blockPosition.z * Consts.Chunk.CHUNK_WIDTH;
                return chunkData.LeftChunk.Blocks[index];
            }

            if (blockPosition.x >= Consts.Chunk.CHUNK_WIDTH)
            {
                if (chunkData.RightChunk == null) return BlockType.Air;

                blockPosition.x -= Consts.Chunk.CHUNK_WIDTH;
                index = blockPosition.x + blockPosition.y * Consts.Chunk.CHUNK_WIDTH_SQ +
                        blockPosition.z * Consts.Chunk.CHUNK_WIDTH;
                return chunkData.RightChunk.Blocks[index];
            }

            if (blockPosition.z < 0)
            {
                if (chunkData.BackChunk == null) return BlockType.Air;

                blockPosition.z += Consts.Chunk.CHUNK_WIDTH;
                index = blockPosition.x + blockPosition.y * Consts.Chunk.CHUNK_WIDTH_SQ +
                        blockPosition.z * Consts.Chunk.CHUNK_WIDTH;
                return chunkData.BackChunk.Blocks[index];
            }

            if (blockPosition.z >= Consts.Chunk.CHUNK_WIDTH)
            {
                if (chunkData.ForwardChunk == null) return BlockType.Air;

                blockPosition.z -= Consts.Chunk.CHUNK_WIDTH;
                index = blockPosition.x + blockPosition.y * Consts.Chunk.CHUNK_WIDTH_SQ +
                        blockPosition.z * Consts.Chunk.CHUNK_WIDTH;
                return chunkData.ForwardChunk.Blocks[index];
            }

            return BlockType.Air;
        }
    }
}