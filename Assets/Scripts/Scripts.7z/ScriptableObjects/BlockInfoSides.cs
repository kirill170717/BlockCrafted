﻿using ChunkScripts.Enums;
using UnityEngine;

namespace ScriptableObjects
{
    [CreateAssetMenu(menuName = "SO's/BlocksInfoSides", fileName = "BlockSides")]
    public class BlockInfoSides : BlockInfo
    {
        public Vector2 PixelsOffsetUp;
        public Vector2 PixelsOffsetDown;

        public override Vector2 GetPixelOffset(BlockSide blockSide)
        {
            return blockSide switch
            {
                BlockSide.Up => PixelsOffsetUp,
                BlockSide.Down => PixelsOffsetDown,
                _ => base.GetPixelOffset(blockSide)
            };
        }
    }
}